"""
Helper and Utility Functions
"""
import re

def format_book_display(book_dict: dict) -> str:
    status = "[BORROWED]" if book_dict.get('is_borrowed') else "[AVAILABLE]"
    return f"{status} #{book_dict.get('id')}: {book_dict.get('title')} by {book_dict.get('author')}"

def validate_isbn(isbn_str: str) -> bool:
    clean = re.sub(r'[-\s]', '', isbn_str)
    return len(clean) in (10, 13)
