"""
CLI Application Runner
"""
import sys
import argparse
from services.catalog import CatalogService
from utils.helpers import format_book_display

def main():
    parser = argparse.ArgumentParser(description="Library Command Line Utility")
    parser.add_argument('--list', action='store_true', help="List all catalog books")
    args = parser.parse_args()

    service = CatalogService()
    if args.list:
        for book in service.list_books():
            print(format_book_display(book))
    else:
        # FIXME: Add interactive prompt if no CLI flags are supplied
        print("Use --list to view books.")

if __name__ == '__main__':
    main()
