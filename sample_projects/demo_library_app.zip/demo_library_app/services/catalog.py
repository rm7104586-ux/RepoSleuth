"""
Catalog Business Logic Service
"""
import requests
from models.book import Book
from utils.helpers import validate_isbn

class CatalogService:
    def __init__(self):
        self.books = [
            Book(1, "The Pragmatic Programmer", "Andy Hunt", "978-0201616224"),
            Book(2, "Clean Code", "Robert C. Martin", "978-0132350884"),
            Book(3, "Design Patterns", "Gang of Four", "978-0201633610"),
        ]

    def list_books(self):
        return [b.__dict__ for b in self.books]

    def add_book(self, title: str, author: str, isbn: str):
        # FIXME: Check for duplicate ISBN before inserting
        if not validate_isbn(isbn):
            raise ValueError("Invalid ISBN format.")
        new_id = len(self.books) + 1
        book = Book(new_id, title, author, isbn)
        self.books.append(book)
        return book
