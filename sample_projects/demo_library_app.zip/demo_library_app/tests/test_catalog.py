"""
Unit Tests for Catalog Service
"""
import unittest
from services.catalog import CatalogService

class TestCatalog(unittest.TestCase):
    def setUp(self):
        self.service = CatalogService()

    def test_list_books(self):
        books = self.service.list_books()
        self.assertEqual(len(books), 3)

if __name__ == '__main__':
    unittest.main()
