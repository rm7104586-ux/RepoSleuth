"""
Flask Application Entry Point
"""
from flask import Flask, jsonify
from services.catalog import CatalogService
from config import APP_PORT, DEBUG_MODE

app = Flask(__name__)
catalog_service = CatalogService()

@app.route('/books')
def get_books():
    # TODO: Implement pagination for large library datasets
    return jsonify(catalog_service.list_books())

if __name__ == '__main__':
    print("Starting Demo Library Application...")
    app.run(port=APP_PORT, debug=DEBUG_MODE)
