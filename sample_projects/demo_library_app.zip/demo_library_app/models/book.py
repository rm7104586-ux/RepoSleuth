"""
Book Data Model
"""
from dataclasses import dataclass

@dataclass
class Book:
    id: int
    title: str
    author: str
    isbn: str
    is_borrowed: bool = False

    def toggle_borrow(self) -> None:
        self.is_borrowed = not self.is_borrowed
