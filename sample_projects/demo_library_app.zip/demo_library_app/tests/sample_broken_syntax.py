"""
Intentional syntax error for testing AST issue detection
"""
def broken_calculator():
    # Intentionally missing parenthesis and colon
    if True
        print "Missing colon and parenthesis"
