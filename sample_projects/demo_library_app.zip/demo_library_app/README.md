# Demo Library Application
A sample Python application with Flask endpoints, CLI interface, dataclass models, and business logic.
