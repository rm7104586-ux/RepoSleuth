"""
Application Configuration
"""
import os

APP_PORT = int(os.environ.get('PORT', 5000))
DEBUG_MODE = True
SECRET_KEY = "demo-secret-key-for-sleuth"
# TODO: Store sensitive secrets in environment variables
